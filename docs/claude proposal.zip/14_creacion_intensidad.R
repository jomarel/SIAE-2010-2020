# ================================
# 14_creacion_intensidad.R
# Crea la variable 'intensidad' (minutos de prueba diagnóstica por alta)
# ================================

config_path <- if (file.exists("scripts/00_config.R")) "scripts/00_config.R" else "00_config.R"
source(config_path)

# NOTA: se ha eliminado setwd() — el working directory NO debe cambiar
# dentro de un script de pipeline porque afecta a todos los pasos siguientes.
# Las rutas absolutas definidas en 00_config.R hacen innecesario setwd().

library(dplyr)

# ── Cargar datos ─────────────────────────────────────────────────────────────
load(DF_SELECCION_RDATA_PATH)
cat(sprintf("df_seleccion cargado: %d filas x %d columnas\n",
            nrow(df_seleccion), ncol(df_seleccion)))

# ── Eliminar duplicados exactos ──────────────────────────────────────────────
n_antes <- nrow(df_seleccion)
df_seleccion <- df_seleccion %>% distinct()
n_dup <- n_antes - nrow(df_seleccion)
if (n_dup > 0) message("Eliminados ", n_dup, " duplicados exactos.")

# Verificar que (NCODI, anyo) es clave única
if (any(duplicated(df_seleccion[, c("NCODI", "anyo")]))) {
  warning("(NCODI, anyo) NO es clave unica tras eliminar duplicados. Revisar datos.")
}

# ── Pesos de las pruebas diagnósticas (minutos estimados por prueba) ─────────
# Fuente: tiempos estándar de radiología / literatura clínica.
# Cambiar aquí para actualizar los pesos sin tocar el resto del código.
pesos_pruebas <- c(
  biopsias     =   60,
  angio        =  750,
  densiometrias = 100,
  gamma        =  250,
  mamo         =   50,
  pet          = 1200,
  resonancia   =  450,
  rx           =   30,
  spect        =  400,
  tac          =  300
)

# ── Calcular intensidad ───────────────────────────────────────────────────────
# intensidad = minutos totales de prueba / número de altas
# Si no hay altas (altFinal_total == 0) el resultado es NA para evitar
# divisiones por cero que producirían Inf.

df_seleccion <- df_seleccion %>%
  mutate(
    intensidad_numerador =
      (biopsias_total      * pesos_pruebas["biopsias"])     +
      (angio_total         * pesos_pruebas["angio"])        +
      (densiometrias_total * pesos_pruebas["densiometrias"]) +
      (gamma_total         * pesos_pruebas["gamma"])        +
      (mamo_total          * pesos_pruebas["mamo"])         +
      (pet_total           * pesos_pruebas["pet"])          +
      (resonancia_total    * pesos_pruebas["resonancia"])   +
      (rx_total            * pesos_pruebas["rx"])           +
      (spect_total         * pesos_pruebas["spect"])        +
      (tac_total           * pesos_pruebas["tac"]),

    intensidad = if_else(
      altFinal_total > 0,
      intensidad_numerador / altFinal_total,
      NA_real_
    )
  )

# ── Diagnóstico ───────────────────────────────────────────────────────────────
cat("\nResumen intensidad_numerador:\n")
print(summary(df_seleccion$intensidad_numerador))
cat("\nResumen intensidad:\n")
print(summary(df_seleccion$intensidad))
cat(sprintf("\nNA en intensidad: %d (%.1f%%)\n",
            sum(is.na(df_seleccion$intensidad)),
            mean(is.na(df_seleccion$intensidad)) * 100))

# ── Guardar ───────────────────────────────────────────────────────────────────
# En el script original este save() faltaba: el resultado se perdía.
save(df_seleccion, file = DF_SELECCION_RDATA_PATH)
write.csv(df_seleccion,
          file.path(OUT_DIR, "df_seleccion_con_intensidad.csv"),
          row.names = FALSE)

cat("\nGuardado en:\n  ", DF_SELECCION_RDATA_PATH, "\n")
