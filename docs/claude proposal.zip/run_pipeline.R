# ================================
# run_pipeline.R
# Script maestro — ejecuta el pipeline SIAE completo
# ================================

# ── Configuración ────────────────────────────────────────────────────────────
config_path <- if (file.exists("scripts/00_config.R")) "scripts/00_config.R" else "00_config.R"
source(config_path)

# ── Scripts en orden de ejecución ────────────────────────────────────────────
# NOTA: los nombres deben coincidir EXACTAMENTE con los archivos en disco.
# Los espacios en los nombres originales han sido reemplazados por guiones bajos.
scripts <- c(
  "scripts/1_cambiarnombredevariables_2.R",
  "scripts/2_seleccionar_var_bucle.R",
  "scripts/3_unir_todo_y_crear_panel.R",
  "scripts/9_construccion_de_variable_mix.R",
  "scripts/10_depuracion_df_completo.R",
  "scripts/11_comprobacion_de_variables_y_simplificacion.R",
  "scripts/12_etiquetas.R",
  "scripts/13_reduccion_variables.R",
  "scripts/14_creacion_intensidad.R"
)

# ── Ejecución con manejo de errores ─────────────────────────────────────────
cat("=== Inicio del pipeline SIAE ===\n")
cat("Fecha:", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

results <- list()

for (s in scripts) {

  # Comprobar que el archivo existe antes de intentar ejecutarlo
  if (!file.exists(s)) {
    msg <- paste("ARCHIVO NO ENCONTRADO:", s)
    warning(msg)
    results[[s]] <- list(status = "missing", error = msg)
    next
  }

  cat(sprintf("[ RUN ] %s\n", s))
  t0 <- proc.time()

  tryCatch(
    {
      source(s, echo = FALSE)
      elapsed <- round((proc.time() - t0)[["elapsed"]], 1)
      cat(sprintf("[  OK ] %s  (%.1f s)\n\n", s, elapsed))
      results[[s]] <- list(status = "ok", elapsed_s = elapsed)
    },
    error = function(e) {
      cat(sprintf("[ ERR ] %s\n  -> %s\n\n", s, conditionMessage(e)))
      results[[s]] <<- list(status = "error", error = conditionMessage(e))
    },
    warning = function(w) {
      # Los warnings no detienen el pipeline, pero quedan registrados
      cat(sprintf("[WARN ] %s\n  -> %s\n", s, conditionMessage(w)))
      invokeRestart("muffleWarning")
    }
  )
}

# ── Resumen final ────────────────────────────────────────────────────────────
cat("=== Resumen del pipeline ===\n")
for (s in names(results)) {
  r <- results[[s]]
  status_label <- switch(r$status,
    ok      = "OK     ",
    error   = "ERROR  ",
    missing = "FALTA  ",
    "??     "
  )
  detail <- if (r$status == "ok") {
    sprintf("%.1f s", r$elapsed_s)
  } else {
    r$error
  }
  cat(sprintf("  %s %s  |  %s\n", status_label, basename(s), detail))
}

n_errors <- sum(sapply(results, function(r) r$status %in% c("error", "missing")))
if (n_errors == 0) {
  cat("\n=== Pipeline finalizado SIN errores ===\n")
} else {
  cat(sprintf("\n=== Pipeline finalizado CON %d paso(s) fallido(s) ===\n", n_errors))
}
