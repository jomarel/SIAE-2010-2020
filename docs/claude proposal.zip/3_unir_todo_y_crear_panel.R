# ================================
# 3_unir_todo_y_crear_panel.R
# Une los CSV anuales en un único panel longitudinal
# ================================

config_path <- if (file.exists("scripts/00_config.R")) "scripts/00_config.R" else "00_config.R"
source(config_path)

library(dplyr)
library(readr)

# ── Detectar archivos anuales disponibles ────────────────────────────────────
# Los CSV anuales se guardan en INT_DIR (ya no en LEGACY_BASE_DIR)
year_files <- list.files(
  path    = INT_DIR,
  pattern = "^df_[0-9]{4}\\.csv$",
  full.names = TRUE
)

if (length(year_files) == 0) {
  stop("No se encontraron archivos df_YYYY.csv en: ", INT_DIR)
}

years <- as.integer(sub("^df_([0-9]{4})\\.csv$", "\\1", basename(year_files)))
ord        <- order(years)
year_files <- year_files[ord]
years      <- years[ord]

cat(sprintf("Archivos encontrados: %d  |  anos: %s\n",
            length(year_files), paste(years, collapse = ", ")))

# ── Leer y apilar ────────────────────────────────────────────────────────────
# dplyr::bind_rows() (a diferencia de rbind) tolera columnas
# distintas entre años: rellena con NA donde una columna no existe.
# Esto es habitual en datos administrativos que cambian de estructura.

list_df <- lapply(seq_along(year_files), function(i) {
  df <- readr::read_csv(
    year_files[i],
    show_col_types = FALSE,
    progress       = FALSE
  )
  df$anyo <- years[i]   # garantiza que la columna de año es correcta
  df
})

# Informe de columnas por año (útil para detectar cambios de estructura)
col_counts <- sapply(list_df, ncol)
if (length(unique(col_counts)) > 1) {
  message("AVISO: los archivos anuales tienen distinto numero de columnas:")
  for (i in seq_along(year_files)) {
    message("  ", years[i], ": ", col_counts[i], " columnas")
  }
  message("Las columnas faltantes se rellenaran con NA (comportamiento esperado).")
}

df_final <- dplyr::bind_rows(list_df)

# Columna año al frente
df_final <- df_final %>% select(anyo, NCODI, everything())

cat(sprintf("Panel creado: %d filas x %d columnas\n", nrow(df_final), ncol(df_final)))

# ── Guardar ──────────────────────────────────────────────────────────────────
save(df_final, file = DF_FINAL_RDATA_PATH)
write.table(df_final, DF_FINAL_TXT_PATH, row.names = FALSE, sep = ";", dec = ",")

cat("Guardado en:\n  ", DF_FINAL_RDATA_PATH, "\n  ", DF_FINAL_TXT_PATH, "\n")
