# ================================
# 9_construccion_de_variable_mix.R
# Construye la variable 'mix' (case-mix) mediante Random Forest + Lasso
# ================================

config_path <- if (file.exists("scripts/00_config.R")) "scripts/00_config.R" else "00_config.R"
source(config_path)

library(dplyr)
library(caret)
library(glmnet)
library(randomForest)

# ── Cargar datos ─────────────────────────────────────────────────────────────
df_final <- read.table(DF_FINAL_TXT_PATH, sep = ";", dec = ",", header = TRUE)
pesos    <- read.table(PESOS_TXT_PATH,    sep = ";", dec = ",", header = TRUE)

df <- left_join(df_final, pesos, by = c("NCODI", "anyo"))

# ── Preparar variables ────────────────────────────────────────────────────────
variables_excluir <- c(
  "NCODI", "anyo", "ccaa_codigo", "ccaa",
  "cod_finalidad_agrupada", "Finalidad_agrupada",
  "cod_depend_agrupada", "Depend_agrupada"
)

variables_numericas <- names(df)[!(names(df) %in% variables_excluir)]
df[variables_numericas] <- lapply(df[variables_numericas],
                                  function(x) as.numeric(as.character(x)))

# Excluir variables con más del 50% de NA
porcentaje_na       <- sapply(df[variables_numericas], function(x) mean(is.na(x)))
variables_muchos_na <- names(porcentaje_na[porcentaje_na > 0.50])
variables_numericas <- setdiff(variables_numericas, variables_muchos_na)
cat(sprintf("Variables con >50%% NA excluidas: %d\n", length(variables_muchos_na)))

# Imputar NA restantes con la mediana
for (var in variables_numericas) {
  med <- median(df[[var]], na.rm = TRUE)
  df[[var]][is.na(df[[var]])] <- med
}

# ── Dividir en entrenamiento (peso conocido) y predicción ────────────────────
df_entrenamiento <- df %>% filter(!is.na(peso))
df_prediccion    <- df %>% filter( is.na(peso))

cat(sprintf("Entrenamiento: %d obs  |  Prediccion: %d obs\n",
            nrow(df_entrenamiento), nrow(df_prediccion)))

X_entrenamiento <- as.matrix(df_entrenamiento[, variables_numericas])
y_entrenamiento <- df_entrenamiento$peso

# ── Eliminar variables con varianza cero ─────────────────────────────────────
nzv                    <- nearZeroVar(X_entrenamiento, saveMetrics = TRUE)
variables_cero_var     <- rownames(nzv[nzv$zeroVar, ])
variables_numericas    <- setdiff(variables_numericas, variables_cero_var)
X_entrenamiento        <- X_entrenamiento[, variables_numericas, drop = FALSE]
cat(sprintf("Variables con varianza cero eliminadas: %d\n", length(variables_cero_var)))

# ── Estandarizar (una sola vez, guardando el objeto preProc) ─────────────────
# CORRECCIÓN: en la versión original se estandarizaba dos veces —
# primero X_entrenamiento completo y luego X_entrenamiento_sel con el
# mismo preProc ajustado sobre el conjunto mayor. Esto introduce sesgo
# porque las escalas se calculan sobre columnas distintas.
# Ahora: (1) selección Lasso sobre datos SIN estandarizar, 
#         (2) preProc ajustado SOLO sobre las variables seleccionadas.

# ── Paso 1: Lasso para selección de variables ────────────────────────────────
# Estandarizamos temporalmente para Lasso (glmnet lo acepta directamente
# con standardize = TRUE, que es el default, así que no hace falta hacerlo
# a mano antes de llamar a cv.glmnet).

set.seed(123)
cv_lasso <- cv.glmnet(
  x         = X_entrenamiento,
  y         = y_entrenamiento,
  alpha     = 1,
  nfolds    = 10,
  standardize = TRUE   # glmnet estandariza internamente
)

lambda_optimo        <- cv_lasso$lambda.min
coeficientes         <- coef(cv_lasso, s = lambda_optimo)
variables_seleccionadas <- rownames(coeficientes)[which(coeficientes != 0)]
variables_seleccionadas <- variables_seleccionadas[variables_seleccionadas != "(Intercept)"]

cat(sprintf("Variables seleccionadas por Lasso: %d\n", length(variables_seleccionadas)))

# ── Paso 2: Estandarizar SOLO las variables seleccionadas ────────────────────
X_entrenamiento_sel <- X_entrenamiento[, variables_seleccionadas, drop = FALSE]

# preProc se ajusta sobre el conjunto de entrenamiento con las vars seleccionadas
preProc <- preProcess(X_entrenamiento_sel, method = c("center", "scale"))
X_entrenamiento_sel <- predict(preProc, X_entrenamiento_sel)

# ── Paso 3: Preparar conjunto de predicción con las mismas transformaciones ──
X_prediccion_raw <- as.matrix(df_prediccion[, variables_numericas, drop = FALSE])

# Columnas faltantes en predicción → rellenar con 0 (equivale a la media
# tras estandarizar, ya que la media del entrenamiento ≈ 0 en escala Z)
faltantes <- setdiff(variables_seleccionadas, colnames(X_prediccion_raw))
if (length(faltantes) > 0) {
  message("Columnas faltantes en prediccion (se imputan con 0 en escala Z): ",
          paste(faltantes, collapse = ", "))
  for (col in faltantes) X_prediccion_raw <- cbind(X_prediccion_raw, setNames(
    data.frame(rep(NA_real_, nrow(X_prediccion_raw))), col))
}

X_prediccion_sel <- X_prediccion_raw[, variables_seleccionadas, drop = FALSE]

# Aplicar el MISMO preProc ajustado sobre entrenamiento
X_prediccion_sel <- predict(preProc, X_prediccion_sel)

# ── Paso 4: Random Forest ─────────────────────────────────────────────────────
mtry_optimo <- max(1, min(floor(sqrt(ncol(X_entrenamiento_sel))),
                          ncol(X_entrenamiento_sel)))

set.seed(123)
modelo_rf <- randomForest(
  x          = X_entrenamiento_sel,
  y          = y_entrenamiento,
  mtry       = mtry_optimo,
  importance = TRUE
)

cat("\nImportancia de variables (top 10):\n")
imp <- importance(modelo_rf)
print(head(imp[order(-imp[, "%IncMSE"]), ], 10))

# ── Paso 5: Predicciones y construcción de 'mix' ─────────────────────────────
df_entrenamiento$mix <- predict(modelo_rf, X_entrenamiento_sel)

if (nrow(df_prediccion) > 0) {
  df_prediccion$mix <- predict(modelo_rf, X_prediccion_sel)
} else {
  message("No hay observaciones sin peso: df_prediccion esta vacio.")
}

df <- bind_rows(df_entrenamiento, df_prediccion)

cat("\nResumen de 'mix':\n")
print(summary(df$mix))

# ── Guardar ───────────────────────────────────────────────────────────────────
write.table(df, DF_FINAL_CON_MIX_TXT_PATH, sep = ";", dec = ",", row.names = FALSE)
cat("\nGuardado en:", DF_FINAL_CON_MIX_TXT_PATH, "\n")
