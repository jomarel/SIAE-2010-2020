# ================================
# 00_config.R
# Configuración central del proyecto
# ================================

# ── Carpeta raíz ────────────────────────────────────────────────────────────
# Cambia solo esta línea para mover el proyecto a otro equipo o unidad.
BASE_DIR <- "G:/Mi unidad/SIAE 2010-2020"

# ── Subcarpetas estándar ─────────────────────────────────────────────────────
RAW_DIR     <- file.path(BASE_DIR, "data_raw")
INT_DIR     <- file.path(BASE_DIR, "data_intermediate")
OUT_DIR     <- file.path(BASE_DIR, "outputs")
DOCS_DIR    <- file.path(BASE_DIR, "docs")
SCRIPTS_DIR <- file.path(BASE_DIR, "scripts")

# Crear directorios si no existen (no falla si ya existen)
for (.d in c(INT_DIR, OUT_DIR, DOCS_DIR)) {
  if (!dir.exists(.d)) dir.create(.d, recursive = TRUE, showWarnings = FALSE)
}
rm(.d)

# ── Artefactos del pipeline ──────────────────────────────────────────────────
# Todos los archivos intermedios y finales viven bajo BASE_DIR.
# LEGACY_BASE_DIR se mantiene únicamente para compatibilidad con archivos
# ya generados; los scripts nuevos deben usar las rutas INT_DIR / OUT_DIR.

LEGACY_BASE_DIR <- BASE_DIR   # <-- unificado: ya no apunta a "h:/"

PESOS_TXT_PATH                        <- file.path(INT_DIR,  "pesos.txt")
DF_FINAL_RDATA_PATH                   <- file.path(INT_DIR,  "df_final.RData")
DF_FINAL_TXT_PATH                     <- file.path(INT_DIR,  "df_final.txt")
DF_COMPLETO_RDATA_PATH                <- file.path(INT_DIR,  "df_completo.RData")
DF_COMPLETO_ACTUALIZADO_RDATA_PATH    <- file.path(INT_DIR,  "df_completo_actualizado.RData")
DF_COMPLETO_ACTUALIZADO_TXT_PATH      <- file.path(INT_DIR,  "df_completo_actualizado.txt")
DF_FINAL_CON_MIX_TXT_PATH            <- file.path(INT_DIR,  "df_final_con_mix.txt")
DF_DEPURADO_RDATA_PATH                <- file.path(INT_DIR,  "df_depurado.RData")
DF_DEPURADO_TXT_PATH                  <- file.path(INT_DIR,  "df_depurado.txt")
DF_DEPURADO_CSV_PATH                  <- file.path(INT_DIR,  "df_depurado.csv")
NOMBRES_ETIQUETAS_TXT_PATH            <- file.path(DOCS_DIR, "nombres_y_etiquetas.txt")
DF_CON_ETIQUETAS_CSV_PATH             <- file.path(OUT_DIR,  "df_con_etiquetas.csv")
DF_SELECCION_CSV_PATH                 <- file.path(INT_DIR,  "df_seleccion.csv")
DF_SELECCION_RDATA_PATH               <- file.path(INT_DIR,  "df_seleccion.RData")
DICCIONARIO_VARS_PATH                 <- file.path(DOCS_DIR, "variables_descripcion_305.csv")

message("Configuracion cargada correctamente. BASE_DIR = ", BASE_DIR)
